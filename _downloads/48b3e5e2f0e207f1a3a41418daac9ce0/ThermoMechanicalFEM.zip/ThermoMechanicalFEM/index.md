---
papersize: a4paper
geometry: margin=1in
---

# Thermo-Mechanical FEM Solver
## Coupling Thermal and Mechanical Simulation in Python

**Supervisors:** Ruben Schmeitz, Joris Remmers

<a href="ThermoMechanicalFEM.zip" download="ThermoMechanicalFEM.zip">
  <img src="https://img.shields.io/badge/Download-All–Assets–orange" alt="Download Zip">
</a>

*[Link](https://jorisremmers.com) for information and video*
## Background

Thermo-mechanical coupling is critical in Powder Bed Fusion (PBF) additive manufacturing, where rapid, localized heating and cooling drive both melt-pool formation and the buildup of residual stresses that cause warping, cracking, and dimensional inaccuracies. To minimize these defects, it is necessary to understand how printer parameters (laser power, scan speed, hatch spacing) and toolpath patterns influence both melt geometry and stress accumulation.

This project extends a provided Python-based FEM framework that currently performs fast thermal analysis and identifies the melt zone by marking elements whose temperature exceeds a prescribed threshold as solidified geometry.

![2D thermal simulation of powder melting and solidification, showing the progression of the melt zone over time ([Link](https://jorisremmers.com))](./FEM.gif)


Based on this model, simple 2D toolpaths can be generated to produce the intended part geometry. The next step is to couple the thermal simulation with a structural solver that computes the residual stresses and deformations arising during cooling and solidification.

## Project Tasks

* Develop coupled thermo-mechanical model including transient heat conduction and temperature-dependent elasticity
* Optimize implementation using sparse matrices and efficient time-stepping schemes
* Validate results against analytical solutions and commercial software benchmarks

## Recommended Reading

* **[On the Simulation Scalability of Predicting Residual Stress and Distortion in Selective Laser Melting](https://doi.org/10.1115/1.4038893)**
* **[A pragmatic part scale model for residual stress and distortion prediction in powder bed fusion](https://doi.org/10.1016/j.addma.2018.05.038)**
* **[Thermo-mechanical simulations of powder bed fusion processes: accuracy and efficiency](https://doi.org/10.1186/s40323-022-00230-y)**