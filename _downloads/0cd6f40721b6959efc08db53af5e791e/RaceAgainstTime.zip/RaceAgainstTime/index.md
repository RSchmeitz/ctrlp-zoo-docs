---
papersize: a4paper
geometry: margin=1in
---

# Race Against Time
## GPU-Accelerated Finite Element Methods for High-Performance Computing

**Supervisors:** Ruben Schmeitz, Maarten Hodzelmans, Joris Remmers

<a href="GPUAcceleratedFEM.zip" download="GPUAcceleratedFEM.zip">
  <img src="https://img.shields.io/badge/Download-All–Assets–orange" alt="Download Zip">
</a>

*[Link](https://jorisremmers.com) for information and video*

## Background

Modern engineering simulations require increasingly detailed models to capture complex phenomena in additive manufacturing, structural optimization, and materials science. Our current Python-based FEM framework is used extensively for optimizing 3D printing toolpaths, which requires millions of repeated simulations to evaluate different printing strategies. Even with a relatively coarse mesh (typically 10x10 elements) optimization times several hours. To make matters worse, accurately capturing local thermal and mechanical phenomena requires much finer meshes with thousands of elements.

This computational bottleneck severely limits our ability to explore different toolpath strategies and perform real-time optimization during printing. Graphics Processing Units (GPUs) offer a solution with their massive parallel computing capability, potentially speeding up each simulation by 10-100x, reducing optimization times from days to minutes. As an optional extension, neural networks could be developed to further accelerate the GPU-based simulations while maintaining physical accuracy.

![Current CPU-based FEM simulation running on a 100x100 mesh ([Link](https://jorisremmers.com))](./FEM.gif)


## Project Tasks

* Implement core FEM operations on GPU using frameworks like CUDA, CuPy, or JAX
* Optimize memory patterns and create a user-friendly Python interface
* Validate implementation through benchmarking and document performance improvements

## Recommended Reading
* **[GPU Accelerated Finite Element Assembly with Runtime Compilation](https://arxiv.org/abs/1802.03433)**
* **[Targeting Performance and User-Friendliness: GPU-Accelerated Finite Element Computation with Automated Code Generation in FEniCS](https://doi.org/10.1016/j.parco.2023.103051)**
* **[JAX-FEM: A Differentiable GPU-Accelerated 3D Finite Element Solver](https://doi.org/10.1016/j.cpc.2023.108802)**

