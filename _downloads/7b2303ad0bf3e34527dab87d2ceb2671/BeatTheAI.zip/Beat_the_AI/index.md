---
papersize: a4paper
geometry: margin=1in
---

# Beat the AI Agent 
## Hand‑Crafted Fill Strategies vs. RL Fill Agent

**Supervisors:** Ruben Schmeitz, Joris Remmers

<a href="BeatTheAI.zip" download="BeatTheAI.zip">
  <img src="https://img.shields.io/badge/Download-All–Assets–orange" alt="Download Zip">
</a>

*[Link](https://jorisremmers.com) for information and video*

## Background

Additive manufacturing relies heavily on efficient toolpath generation for internal fill patterns. While our reinforcement learning agent has shown impressive results in optimizing these paths, there's still potential for well-designed heuristic approaches to outperform AI in certain scenarios.

Our framework simplifies the challenge into a 2D grid where a pointer moves cell-by-cell, toggling fill states. The constraints are clear: limited moves, no revisiting filled cells. While a basic zigzag pattern works for simple shapes, it struggles with complex geometries. Our AI agent learns to navigate efficiently, but handcrafted strategies remain unexplored.

![**Video 1.** Comparison of continuous AI path versus zigzag approach](./combined.gif)

## Project Tasks

* Design and implement geometric-based filling algorithms including spiral and boundary-following patterns
* Build test suite to measure and compare performance metrics against AI and zigzag baselines
* Analyze strategy effectiveness and document optimal use cases for each approach

## Recommended Reading

* **[Toolpath Planning in Additive Manufacturing](https://doi.org/10.1016/j.cad.2019.102768)**
* **[Spiral and Zigzag Toolpaths for FDM](https://doi.org/10.1016/j.jmsy.2018.12.003)**
* **[Geometric Algorithms for Toolpath Planning](https://doi.org/10.1016/j.cad.2020.102860)**